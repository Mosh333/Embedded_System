Please make sure to select the correct ELF when trying to compile the exercises. 
Despite the fact that we cleaned the projects, Nios II seems to force the folder directory
for the account the exercises were worked in. Sorry for the inconvenience.
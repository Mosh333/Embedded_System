/*
 * switches.h
 *
 *  Created on: Jan 29, 2018
 *      Author: ECE\ganesr3
 */

#ifndef _SWITCHES_H__
#define _SWITCHES_H__


void switch_interrupt();
void init_switches_irq();

#endif /* SWITCHES_H_ */

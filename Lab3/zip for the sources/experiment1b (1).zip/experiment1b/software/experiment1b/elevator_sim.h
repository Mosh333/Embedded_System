/*
 * elevator_sim.h
 *
 *  Created on: Jan 29, 2018
 *      Author: ECE\ganesr3
 */

#ifndef ELEVATOR_SIM_H_
#define ELEVATOR_SIM_H_

#include "define.h"


void elevator_sim();
void update_7Seg_Disp();


#endif /* ELEVATOR_SIM_H_ */

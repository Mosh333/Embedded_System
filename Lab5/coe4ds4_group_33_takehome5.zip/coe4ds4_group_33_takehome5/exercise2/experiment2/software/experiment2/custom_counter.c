
#include "define.h"

// ISR when the counter is expired
//SMDSS_params_struct *SMDSS_params_hardware
void handle_SMDSS_expire_interrupts(alt_16 * array)
{
	IOWR(LED_RED_O_BASE, 0, 0x7);

	//printf("\nTHE HARDWARE HAS FOUND THE SMDSS!\n");
	int start=0;
	int length=0;
	int i=0;


	//SMDSS_params_hardware->start=IORD(CUSTOM_COUNTER_COMPONENT_0_BASE, 2);
	//SMDSS_params_hardware->length=IORD(CUSTOM_COUNTER_COMPONENT_0_BASE, 3);
	start= IORD(CUSTOM_COUNTER_COMPONENT_0_BASE, 2);
	length=IORD(CUSTOM_COUNTER_COMPONENT_0_BASE, 3);

	if(length!=1){
		printf("The hardware found the starting index of the SMDSS to be: %d\n",start);
		printf("The hardware found the length of the SMDSS to be: %d\n",length);
	}
	if(length==1){
		printf("There is no SMDSS!!!\n");
	}else{
		printf("\n\nThe longest Monotonic Decreasing Sequence Found by Hardware is:\n");
		for (i = 0; i < length; i++) {
			printf("%d, ", array[start + i]);
		}
	}

	IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 5, 0);
	usleep(10000);

	IOWR(LED_RED_O_BASE, 0, 0xF);
	return;
}

void find_SMDSS_hardware() {
	IOWR(LED_RED_O_BASE, 0, 0xB);

	printf("\nStarting retrieval of SMDSS\n");

	IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 4, 0);// call offset 4 functionality by creating positive edge
	IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 4, 1);

	IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 5, 0);//clear edge register

	IOWR(LED_RED_O_BASE, 0, 0xF);
}




void read_SMDSS(int index) {


			alt_16 wren=1;
			//int data=0;
			int n=0;
			alt_16 data_mask=0xFFFF;
			alt_32 send_data= (alt_32) (((index)<<16)|(wren<<26));
			IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 1,send_data);
			//printf("\nthe write enable is: %d", send_data>>26 & 0x1);
			//printf("\nthe index we are checking is: %d", (send_data>>16)&0x3FF);

			usleep(1000);
			n = IORD(CUSTOM_COUNTER_COMPONENT_0_BASE, 0);
			//printf("\n\nWe are testing the storage in values in the DP-RAM\nThe value in index %d is: %d\n\n",index, n);
			printf("\n\nWe are testing the storage in values in the DP-RAM\n The value in index %d is: %d\n\n",index, (n) );
			//return n;
}

void read_SMDSS_interrupt() {
	//return IORD(CUSTOM_COUNTER_COMPONENT_0_BASE, 2);
}

void  return_SMDSS_length_interrupt(){
	//returns length of SMDSS
	//return IORD(CUSTOM_COUNTER_COMPONENT_0_BASE, 3);
}

void load_subsequence(alt_16 *random_1024_Array) {
	IOWR(LED_RED_O_BASE, 0, 0xD);
	printf("Starting to load the entire sequence into the DPRAM \n\n");
	
	printf("Loading the signed 1024-index array \n");

	int data=0;

	alt_16 addr=0;
	alt_16 wren=0;
	alt_u16 i=0;


	int send_data=0;
	alt_16 addr_mask=0x3FF;
	alt_16 data_mask=0xFFFF;


	for(i=0;i<1024;i++){
		data=0;
		send_data=0;
		data=random_1024_Array[i];

		//send_data=(alt_32)((((addr & addr_mask)<<16)|(data))|(wren<<26));
		send_data = data&0xFFFF;
		send_data |= (addr << 16);
		send_data |= (wren << 26);
		IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 1,send_data);
		//printf("the write enable is: %ld\n", send_data>>26 & 0x1);
		//printf("the address extracted from send data is: %ld\n", send_data>>16 & 0x3FF);
			//printf("the address obtained from variable addr is: %ld\n", addr);
		//printf("writing this number to the dpram: %d\n",data);
			//printf("writing this number to the dpram: %x\n",data );
			//printf("the data to write to dpram is: %x\n\n\n", (alt_16)(send_data&data_mask));
		//printf("the data to write to dpram is: %d\n\n\n", (alt_16)(send_data&data_mask));
		//printf("the data to write to dpram is: %d %d\n\n\n", data, (alt_16)(send_data&data_mask));
		addr++;
		usleep(100);
	}



	IOWR(LED_RED_O_BASE, 0, 0xF);
}

// Function for initializing the ISR of the Counter
//SMDSS_params_struct * SMDSS_params_hardware
void init_SMDSS_irq(alt_16 * array) {
	IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 5, 0);
	//(SMDSS_params_struct *)SMDSS_params_hardware
	alt_irq_register(CUSTOM_COUNTER_COMPONENT_0_IRQ, (alt_16 *) array, handle_SMDSS_expire_interrupts );
	//alt_irq_register(PUSH_BUTTON_I_IRQ, NULL, (void*)handle_button_interrupts );
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////







//// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
//// Developed for the Embedded Systems course (COE4DS4)
//// Department of Electrical and Computer Engineering
//// McMaster University
//// Ontario, Canada
//
//#include "define.h"
//
//// ISR when the counter is expired
//void handle_counter_expire_interrupts()
//{
//	IOWR(LED_RED_O_BASE, 0, 0x7);
//
//	printf("Counter expires\n");
//
//	IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 2, 0);
//
//	IOWR(LED_RED_O_BASE, 0, 0xF);
//}
//
//void reset_counter() {
//	IOWR(LED_RED_O_BASE, 0, 0xB);
//
//	printf("Resetting counter value\n");
//
//	IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 1, 1);
//	IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 1, 0);
//
//	IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 2, 0);
//
//	IOWR(LED_RED_O_BASE, 0, 0xF);
//}
//
//int read_counter() {
//	return IORD(CUSTOM_COUNTER_COMPONENT_0_BASE, 0);
//}
//
//int read_counter_interrupt() {
//	return IORD(CUSTOM_COUNTER_COMPONENT_0_BASE, 2);
//}
//
//void load_counter_config(int config) {
//	IOWR(LED_RED_O_BASE, 0, 0xD);
//	printf("Loading counter value %d\n", config);
//
//	IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 3, config);
//
//	IOWR(LED_RED_O_BASE, 0, 0xF);
//}
//
//// Function for initializing the ISR of the Counter
//void init_counter_irq() {
//	IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 2, 0);
//
//	alt_irq_register(CUSTOM_COUNTER_COMPONENT_0_IRQ, NULL, (void*)handle_counter_expire_interrupts );
//}

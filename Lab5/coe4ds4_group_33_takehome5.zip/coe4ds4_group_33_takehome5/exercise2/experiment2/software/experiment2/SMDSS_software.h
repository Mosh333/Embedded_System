/*
 * SMDSS_software.h
 *
 *  Created on: Feb 10, 2018
 *      Author: ECE\ganesr3
 */

#ifndef SMDSS_SOFTWARE_H_
#define SMDSS_SOFTWARE_H_


#endif /* SMDSS_SOFTWARE_H_ */
void find_SMDSS_software();

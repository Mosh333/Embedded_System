// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

int random_num_gen(int min, int max) {
	return rand() % (max - min + 1) + min;
}

int main() {
	alt_16 random_1024_Array[1024];//1024
	int i = 0;
	IOWR(CUSTOM_COUNTER_COMPONENT_0_BASE, 5, 0);

	//You random on (0, 32767+32768) then subtract by 32768
	SMDSS_params_struct SMDSS_params_software;
	SMDSS_params_software.length = 0;
	SMDSS_params_software.start = 0;

	SMDSS_params_struct SMDSS_params_hardware;
	SMDSS_params_hardware.length = 0;
	SMDSS_params_hardware.start = 0;


//	for (i = 0; i < 1024; i++) {//1024
//		random_1024_Array[i] = 20000;//generate all zeros
//	}
	// Initialize array parameters here
	for (i = 0; i < 1024; i++) {//1024
		random_1024_Array[i] = 0;//generate all zeros
	}


	for (i = 0; i < 1024; i++) {//1024
		//random_1024_Array[i]=8-i;
		random_1024_Array[i] = random_num_gen(0, 65536) - 65536 / 2;//to generate negative numbers as well
	}

	for (i = 5; i < 50; i++) {
		random_1024_Array[i] = 500- i;
	}
	for (i = 800; i < 950; i++) {
		random_1024_Array[i] = 10000 - i;
	}
	random_1024_Array[6] = 0;
	random_1024_Array[20]=0;


	random_1024_Array[600] = -765;
	//random_1024_Array[796] = 21206;
	//random_1024_Array[797] = 21206; //check if monotonic seq circuit checks equality correctly
	/*for (i = 797; i < (797+155); i++) { //generates SMDSS length to be 31
		random_1024_Array[i] = 0;
	}*/
	//random_1024_Array[797] = 54000; //check if signed 54000 in 16 bit representable it is not

	printf("Start main...\n");
	IOWR(LED_GREEN_O_BASE, 0, 0x0);
	IOWR(LED_RED_O_BASE, 0, 0x0);
	//&SMDSS_params_hardware
	init_SMDSS_irq(&random_1024_Array);
	printf("Strictly Monotonic Decreasing SubSequence IRQ initialized...\n");


	//////////////////////////////////////////////////////////////////////////////////////
	//////////////SOFTWARE///////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////
	printf("\n-----------------------------------------------\nSOFTWARE testing begins!\n-----------------------------------------------\n");

	find_SMDSS_software(&SMDSS_params_software, &random_1024_Array);

//	printf("The max length is: %d\n", SMDSS_params_software.length);
//	printf("The start index is: %d\n", SMDSS_params_software.start);


//
//	printf("\n\nSurroundings:\n");
//	for (i = 0 - 5; i < SMDSS_params_software.length + 5; i++) {
//		printf("%d, ", random_1024_Array[SMDSS_params_software.start + i]);
//	}
	//////////////////////////////////////////////////////////////////////////////////////
	//////////////HARDWARE////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////





	printf("\n-----------------------------------------------\nHARDWARE testing begins!\n-----------------------------------------------\n");

	load_subsequence(&random_1024_Array);
	read_SMDSS(3);
	printf("The value that was actually at position 3 in software is: %d\n\n",
			random_1024_Array[3]);
//
//	read_SMDSS(900);
//	printf("The value that was actually at position 900 in software is: %d\n\n",
//			random_1024_Array[900]);
//
//	printf("The first 5 values are:\n");
//	for (i = 0; i < 5; i++) {
//		printf("%d, ", random_1024_Array[i]);
//	}
	printf("\n-----------------------------------------------\nRESULTS:\n-----------------------------------------------\n");
	find_SMDSS_hardware();
	printf("-----------------------------------------------\n");
	if(SMDSS_params_software.length>1){
		printf("The software has found the starting index is: %d\n", SMDSS_params_software.start);
		printf("The max length is: %d\n", SMDSS_params_software.length);
		printf("\n\nthe longest Monotonic Decreasing Sequence found by software is:\n");
		for (i = 0; i < SMDSS_params_software.length; i++) {
			printf("%d, ", random_1024_Array[SMDSS_params_software.start + i]);
		}
	}


	//////////////////////////////////////////////////////////////////////////////////////
	//////////////TESTING////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////


	while (1);

	return 0;
}

/*
 * SMDSS_software.c
 *
 *  Created on: Feb 10, 2018
 *      Author: ECE\ganesr3
 */

#include "define.h"

void find_SMDSS_software(struct SMDSS_params * params, alt_16 * array) {

	int i = 0;

	int current_length = 1;

	int start = 0;


	for (i = 1; i < 1024; i++) {
		if (array[i - 1] > array[i]) {
			current_length++;
		} else {

			if (current_length >= params->length) {
				params->length = current_length;
				params->start = start;
			}
			start = i;
			current_length = 1;
		}

		if (current_length >= params->length) {
			params->length = current_length;
			params->start = start;

		}

	}

}
